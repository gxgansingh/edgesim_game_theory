"""Simulation metrics."""
