"""Simulation entities."""
